@echo off
title AA5PD Allstar Nodes Dashboard
set "HERE=%~dp0"
start "" "%HERE%dashboard.html"
exit
