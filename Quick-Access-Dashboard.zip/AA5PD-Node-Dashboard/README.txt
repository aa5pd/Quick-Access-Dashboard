AA5PD Allstar Nodes Dashboard
Designed by AA5PD, Ham-A-Teur Radio Guy

WHAT THIS IS
This is a self-contained local app. There's nothing to install and no
internet connection needed to run it — everything lives in your browser,
and your saved nodes stay only on the computer you use it on.

HOW TO RUN IT

Windows
  Double-click "Launch-Windows.bat". A browser tab will open with the
  dashboard. (If Windows warns about an unrecognized app the first time,
  choose "More info" > "Run anyway" — it's just a local shortcut, no
  installer, no admin rights needed.)

Mac
  Double-click "Launch-Mac.command". The first time, macOS may block it —
  right-click (or Control-click) the file, choose "Open", then confirm.
  After that it opens normally with a double-click.

Linux
  Double-click "Launch-Linux.sh" if your file manager runs it, or open a
  terminal in this folder and run:
      chmod +x Launch-Linux.sh
      ./Launch-Linux.sh

Any system
  You can always skip the launcher and just open "dashboard.html" directly
  in any browser (Chrome, Firefox, Edge, Safari) — that's all a launcher
  does anyway.

YOUR DATA
Everything you add is saved locally in that browser only (not sent
anywhere). Use the "Export backup" button inside the dashboard to save a
copy of your nodes, and "Import backup" to bring them into another
browser or computer.
