#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
xdg-open "$DIR/dashboard.html" 2>/dev/null || \
sensible-browser "$DIR/dashboard.html" 2>/dev/null || \
x-www-browser "$DIR/dashboard.html" 2>/dev/null || \
echo "Couldn't find a browser to open automatically — open dashboard.html manually."
