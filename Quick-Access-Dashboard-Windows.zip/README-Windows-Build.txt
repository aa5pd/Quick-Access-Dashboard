Quick Access Dashboard — Windows installer build instructions

I can't compile a Windows .exe installer myself — that needs Windows-
specific build tools and, for this one, an internet connection to fetch
them, neither of which I have here. What I've given you instead is a
complete, ready-to-compile installer *script* for Inno Setup, the free,
widely-used tool most small Windows apps use to build their setup
wizards. Turning it into a real Setup.exe takes about 30 seconds once
Inno Setup is installed.

STEPS

1. Download and install Inno Setup (free):
   https://jrsoftware.org/isdl.php
   (Just click through the installer with default options.)

2. Open "Quick-Access-Dashboard.iss" — either double-click it (Inno
   Setup registers itself to open .iss files) or open Inno Setup and
   use File > Open.

3. Click the "Compile" button (or press Ctrl+F9, or Build > Compile).

4. Inno Setup creates the real installer at:
       Output\Quick-Access-Dashboard-Setup.exe
   inside this same folder. That .exe is what you share or run — it's a
   proper Windows installer: install-location picker, optional desktop
   icon, Start Menu entry, its own icon, and a registered uninstaller in
   "Apps & Features" like any other program.

5. Run Quick-Access-Dashboard-Setup.exe to install it. It'll offer to
   launch the dashboard right after installing.

HOW IT OPENS

The shortcuts run a small launcher script that checks for Google Chrome
or Microsoft Edge. If either is installed, it opens the dashboard in a
clean standalone window — no tabs, no address bar, just the dashboard,
like a real app, with its own taskbar icon. If neither is installed
(rare — Edge ships with Windows), it falls back to opening the page in
your default browser normally.

WHAT IT INSTALLS

dashboard.html, a small launcher script (AppLauncher.vbs), and an icon
file. No background service, no other changes to your system — this is
just a shortcut to a local file with a nicer launch experience than
double-clicking the HTML file directly. Your saved nodes live in the
browser, not in these files, so they're unaffected by installing,
moving, or uninstalling.

DON'T WANT TO INSTALL INNO SETUP?

Windows also has a built-in tool called IExpress that can wrap these
files into a self-extracting .exe with no downloads at all — a rougher
result (no install-wizard UI or uninstaller, just extract-and-shortcut),
but if you'd rather use only what's already on your PC, just ask and
I'll walk you through it.
