; Quick Access Dashboard — Windows installer script
; Compile this with Inno Setup (free, from https://jrsoftware.org/isinfo.php)
; to produce a real Setup.exe with a wizard, install-folder picker,
; Start Menu / Desktop shortcuts, and a registered uninstaller.

[Setup]
AppName=Quick Access Dashboard
AppVersion=1.0
AppPublisher=AA5PD
DefaultDirName={autopf}\Quick Access Dashboard
DefaultGroupName=Quick Access Dashboard
UninstallDisplayIcon={app}\app.ico
OutputBaseFilename=Quick-Access-Dashboard-Setup
OutputDir=Output
Compression=lzma
SolidCompression=yes
DisableProgramGroupPage=yes
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop icon"; GroupDescription: "Additional icons:"

[Files]
Source: "dashboard.html"; DestDir: "{app}"; Flags: ignoreversion
Source: "AppLauncher.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "app.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Quick Access Dashboard"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\AppLauncher.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"
Name: "{group}\Uninstall Quick Access Dashboard"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Quick Access Dashboard"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\AppLauncher.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\app.ico"; Tasks: desktopicon

[Run]
Filename: "{sys}\wscript.exe"; Parameters: """{app}\AppLauncher.vbs"""; WorkingDir: "{app}"; Description: "Launch Quick Access Dashboard"; Flags: nowait postinstall skipifsilent
