Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)
url = "file:///" & Replace(here, "\", "/") & "/dashboard.html"

localAppData = shell.ExpandEnvironmentStrings("%LocalAppData%")
programFiles = shell.ExpandEnvironmentStrings("%ProgramFiles%")
programFilesX86 = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%")

chrome1 = programFiles & "\Google\Chrome\Application\chrome.exe"
chrome2 = programFilesX86 & "\Google\Chrome\Application\chrome.exe"
chrome3 = localAppData & "\Google\Chrome\Application\chrome.exe"
edge1 = programFilesX86 & "\Microsoft\Edge\Application\msedge.exe"
edge2 = programFiles & "\Microsoft\Edge\Application\msedge.exe"

windowArgs = " --app=""" & url & """ --window-size=1180,820"

If fso.FileExists(chrome1) Then
  shell.Run """" & chrome1 & """" & windowArgs, 1, False
ElseIf fso.FileExists(chrome2) Then
  shell.Run """" & chrome2 & """" & windowArgs, 1, False
ElseIf fso.FileExists(chrome3) Then
  shell.Run """" & chrome3 & """" & windowArgs, 1, False
ElseIf fso.FileExists(edge1) Then
  shell.Run """" & edge1 & """" & windowArgs, 1, False
ElseIf fso.FileExists(edge2) Then
  shell.Run """" & edge2 & """" & windowArgs, 1, False
Else
  shell.Run """" & here & "\dashboard.html""", 1, False
End If
