Quick Access Dashboard — Mac install

1. Unzip this file if it isn't already.
2. Drag "Quick Access Dashboard.app" into your Applications folder
   (or anywhere you like — it doesn't need to be in Applications to work).
3. Double-click it to open the dashboard in its own app window.

First launch only: macOS blocks apps from unidentified developers by
default. If double-clicking does nothing or shows a warning:
  - Right-click (or Control-click) the app → choose "Open" → click
    "Open" again in the dialog that appears.
  - After that first time, it opens normally with a plain double-click.

HOW IT OPENS

If you have Google Chrome or Microsoft Edge installed, the app opens in
a clean, standalone window — no tabs, no address bar, just the
dashboard, like a real app. It'll show up in the Dock and Cmd+Tab
switcher like any other app while open. If neither browser is
installed, it opens in a normal Safari tab instead — still fully
functional, just not in its own window.

This isn't a signed, notarized .pkg installer — building one of those
requires Apple's own tools running on a Mac, which I don't have access
to. This is the practical equivalent: a real, double-clickable app,
distributed as a zip instead of a signed installer.

Your data (nodes, passwords, etc.) is saved inside the browser the app
uses, not inside the app itself, so it stays put even if you move or
delete the app later.
